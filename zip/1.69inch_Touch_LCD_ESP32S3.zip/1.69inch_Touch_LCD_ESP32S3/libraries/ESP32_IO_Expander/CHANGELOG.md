# ChangeLog

## v0.0.1 - 2023-09-20

### Enhancements:

* Support for various IO expander chips.
* Support to control individual IO in the same way as Arduino
* Support to control multiple IOs at the same time.

## v0.0.2 - 2023-10-07

### Bug Fixes:

* Correct library name in `sentence` field of metadata
